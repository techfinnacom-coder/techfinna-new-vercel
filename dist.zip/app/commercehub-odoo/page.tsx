import CommerceHub from '@/components/Commercehub/Commercehub'
const CommerceHubPage = () => {
  return (
    <div className="flex min-h-screen flex-col items-center justify-between p-24">
        <CommerceHub />
    </div>
  )
}

export default CommerceHubPage