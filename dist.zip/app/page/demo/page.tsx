import DemoPage from "@/components/Contact/demo_page";

const DemoRequestPage = () => {
  return <DemoPage />;
};

export default DemoRequestPage;
