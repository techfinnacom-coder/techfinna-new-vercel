import React from "react";

const Page = async () => {
  return (
    <div className="mt-24">
     hii
    </div>
  );
};

export default Page;
